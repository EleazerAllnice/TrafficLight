#ifndef __ROADWAY_H__
#define __ROADWAY_H__
#include "Vehicle.h"
#include <list>
#include "TrafficLight.h"
#include <vector>
#include <iostream>

class Simulation;

struct intersection{
  int row;
  int col;
}
/**
 struct intersection sb = {row/2, col/2};
 struct intersection nb = {row/2, (col/2)+1};
 struct intersection eb = {(row/2)+1, col/2};
 struct intersection wb = {row/2+1, (col/2)+1};
*/

class Roadway
{
  private:
    TrafficLight ewLight = TrafficLight(LightColor::green, Simulation::getGreenEastWest(), "EW");
    TrafficLight nsLight = TrafficLight(LightColor::red, Simulation::getRedNorthSouth(), "NS");
    int row;
    int col;
    std::vector<std::vector<Vehicle*>> lanes;
    std::list<Vehicle*> carList;
    //void newCars();

  public:
    Roadway(int row, int col);
    void addVehicle(Vehicle* vehicle);
    void moveCars(int time);
    TrafficLight getNSlight();
    TrafficLight getEWlight();
    boolean isNextMoveIntersection(int row, int col);

       ~Roadway();

};

#endif
