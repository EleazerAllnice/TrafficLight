#ifndef __SIMULATION_CPP__
#define __SIMULATION_CPP__

#include "Simulation.h"
#include "TrafficLight.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <random>
#include "random.h"

using namespace std;

int Simulation::green_north_south;
int Simulation::yellow_north_south;
int Simulation::green_east_west;
int Simulation::yellow_east_west;
int Simulation::maximum_simulated_time;
int Simulation::number_of_sections_before_intersection;
int Simulation::prob_new_vehicle_northbound;
int Simulation::prob_new_vehicle_southbound;
int Simulation::prob_new_vehicle_eastbound;
int Simulation::prob_new_vehicle_westbound;
int Simulation::proportion_of_cars;
int Simulation::proportion_of_SUVs;
int Simulation::proportion_of_trucks = 1 - proportion_of_SUVs - proportion_of_cars;
int Simulation::proportion_right_turn_cars;
int Simulation::proportion_left_turn_cars;
int Simulation::proportion_right_turn_SUVs;
int Simulation::proportion_left_turn_SUVs;
int Simulation::proportion_right_turn_trucks;
int Simulation::proportion_left_turn_trucks;
int Simulation::red_east_west = yellow_north_south + green_north_south;
int Simulation::red_north_south = yellow_east_west + green_east_west;

int Simulation::getMaximumSimulatedTime()
{
	return maximum_simulated_time;
}
int Simulation::getNumberOfSections()
{
	return number_of_sections_before_intersection;
}
int Simulation::getYellowNorthSouth()
{
	return yellow_north_south;
}
int Simulation::getYellowEastWest()
{
	return yellow_east_west;
}
int Simulation::getGreenNorthSouth()
{
	return green_north_south;
}
int Simulation::getGreenEastWest()
{
	return green_east_west;
}
int Simulation::getRedNorthSouth()
{
	return red_north_south;
}
int Simulation::getRedEastWest()
{
	return red_east_west;
}
int Simulation::getProbNewVehicleNorthbound()
{
	return prob_new_vehicle_northbound;
}
int Simulation::getProbNewVehicleSouthbound()
{
	return prob_new_vehicle_southbound;
}
int Simulation::getProbNewVehicleEastbound()
{
	return prob_new_vehicle_eastbound;
}
int Simulation::getProbNewVehicleWestbound()
{
	return prob_new_vehicle_westbound;
}
int Simulation::getProportionOfCars()
{
	return proportion_of_cars;
}
int Simulation::getProportionOfSUVs()
{
	return proportion_of_SUVs;
}
int Simulation::getProportionOfTrucks()
{
	return proportion_of_trucks;
}
int Simulation::getProportionOfRightTurnCars()
{
	return proportion_right_turn_cars;
}
int Simulation::getProportionOfRightTurnSUVs()
{
	return proportion_right_turn_SUVs;
}
int Simulation::getProportionOfRightTurnTrucks()
{
	return proportion_right_turn_trucks;
}

void Simulation::run(int seed)
{
	int rowlength = 2 * Simulation::getNumberOfSections() + 2;
	int collength = 2 * Simulation::getNumberOfSections() + 2;
    Roadway road(rowlength,collength);
	TrafficLight t1 = road.getEWlight();
	TrafficLight t2 = road.getNSlight();

	int i = 0;
	while(i <= maximum_simulated_time)
	{
		road.moveCars(i);
		t1.update(i);
		t2.update(i);
		i++;
	}
}

void Simulation::readInputFile(std::string filename)
{
	std::ifstream infile(filename); // to open file reading
	std::string line; //to declare the line being used to read

	while(getline(infile, line))
	{
		maximum_simulated_time = stoi(line);
		getline(infile, line);
		number_of_sections_before_intersection = stoi(line);
		getline(infile, line);
		green_north_south = stoi(line);
		getline(infile, line);
		yellow_north_south = stoi(line);
		getline(infile, line);
		green_east_west = stoi(line);
		getline(infile, line);
		yellow_east_west = stoi(line);
		getline(infile, line);
		prob_new_vehicle_northbound = stoi(line);
		getline(infile, line);
		prob_new_vehicle_southbound = stoi(line);
		getline(infile, line);
		prob_new_vehicle_eastbound = stoi(line);
		getline(infile, line);
		prob_new_vehicle_westbound = stoi(line);
		getline(infile, line);
		proportion_of_cars = stoi(line);
		getline(infile, line);
		proportion_of_SUVs = stoi(line);
		getline(infile, line);
		proportion_right_turn_cars = stoi(line);
		getline(infile, line);
		proportion_left_turn_cars = stoi(line);
		getline(infile, line);
		proportion_right_turn_SUVs = stoi(line);
		getline(infile, line);
		proportion_left_turn_SUVs = stoi(line);
		getline(infile, line);
		proportion_right_turn_trucks = stoi(line);
		getline(infile, line);
		proportion_left_turn_trucks = stoi(line);
	}
		infile.close();

}

int main(int argc, char* argv[]) //command-line arguments are the the intial seed and input file
{
	//all animation stuff happens in main()
	Simulation::readInputFile(argv[2]);
	Random ram = Random(argc);
	Simulation::run(argc);
	int halfsize = Simulation::getNumberOfSections();
	Animator animate(halfsize);


	return(0);
}

#endif
