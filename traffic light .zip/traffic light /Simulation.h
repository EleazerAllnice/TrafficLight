#ifndef __SIMULATION_H__
#define __SIMULATION_H__

#include <string>

#include "Animator.h"

class Roadway;

class Simulation
{
	private:
		int static maximum_simulated_time;
		int static number_of_sections_before_intersection;
		int static green_north_south;
		int static yellow_north_south;
		int static green_east_west;
		int static yellow_east_west;
		int static prob_new_vehicle_northbound;
		int static prob_new_vehicle_southbound;
		int static prob_new_vehicle_eastbound;
		int static prob_new_vehicle_westbound;
		int static proportion_of_cars;
		int static proportion_of_SUVs;
		int static proportion_of_trucks;
		int static proportion_right_turn_cars;
		int static proportion_left_turn_cars;
		int static proportion_right_turn_SUVs;
		int static proportion_left_turn_SUVs;
		int static proportion_right_turn_trucks;
		int static proportion_left_turn_trucks;
		//not read in by file
		int static red_east_west;
		int static red_north_south; //set these lengths of time
	public:
		void static readInputFile(std::string filename);
		int static getMaximumSimulatedTime();
		int static getNumberOfSections();
		int static getYellowNorthSouth();
		int static getYellowEastWest();
		int static getGreenNorthSouth();
		int static getGreenEastWest();
		int static getRedNorthSouth();
		int static getRedEastWest();
		double static getProbNewVehicleNorthbound();
		double static getProbNewVehicleSouthbound();
		double static getProbNewVehicleEastbound();
		double static getProbNewVehicleWestbound();
		double static getProportionOfCars();
		double static getProportionOfSUVs();
		double static getProportionOfTrucks();
		double static getProportionOfRightTurnCars();
		double static getProportionOfRightTurnSUVs();
		double static getProportionOfRightTurnTrucks();
		void static run(int seed);

};

#endif
